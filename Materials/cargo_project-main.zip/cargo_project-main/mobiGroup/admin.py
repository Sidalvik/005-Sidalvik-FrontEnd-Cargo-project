import imp
from django.contrib import admin
from .models import Query ,Test

admin.site.register(Query)
admin.site.register(Test)
