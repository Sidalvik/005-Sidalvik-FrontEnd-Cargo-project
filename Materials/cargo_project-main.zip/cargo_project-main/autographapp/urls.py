from django.urls import path
# from .views import show_autograph_page

urlpatterns = [
	# path('', 	show_autograph_page , name='show_autograph_page'),
]